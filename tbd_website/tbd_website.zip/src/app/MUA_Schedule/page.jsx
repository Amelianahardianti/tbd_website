"use client";

import React, { useEffect, useState } from "react";

// Warna dan font custom, sebaiknya juga didefinisikan di tailwind.config.js
const STATUS_COLORS = {
  "waiting-approval": "bg-gray-200 text-gray-800",
  "approved": "bg-yellow-100 text-yellow-800",
  "in-progress": "bg-blue-100 text-blue-800",
  "completed": "bg-green-100 text-green-800",
  "cancelled": "bg-red-100 text-red-800",
  "rejected": "bg-pink-200 text-red-800",
};

export default function MUASchedulePage() {
  // Simulasi data (ganti dengan fetch dari backend jika sudah ada API)
  const [data, setData] = useState([
    {
      mua_name: "Sarah Makeup",
      expertise: ["Bridal"],
      booking_date: "2025-06-15",
      status: "completed",
    },
    {
      mua_name: "Dian Beauty",
      expertise: ["Editorial", "Graduation"],
      booking_date: "2025-06-20",
      status: "approved",
    },
    {
      mua_name: "Rina Artist",
      expertise: ["Party"],
      booking_date: "2025-06-25",
      status: "waiting-approval",
    },
    {
      mua_name: "Lia Professional",
      expertise: ["Bridal", "Pre-Wedding"],
      booking_date: "2025-07-05",
      status: "waiting-approval",
    },
  ]);

  return (
    <div className="min-h-screen bg-[#faf8f8] font-poppins pb-12">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 w-full z-50 bg-white/95 backdrop-blur-md shadow-md py-2">
        <div className="container mx-auto flex items-center justify-between px-4">
          <a className="flex items-center gap-2" href="#">
            <div
              className="w-10 h-10 bg-center bg-contain bg-no-repeat"
              style={{ backgroundImage: "url('/assets/logo-muar.png')" }}
            ></div>
            <div>
              <div className="font-playfair font-bold text-[1.3rem] lowercase text-primary">
                muar
              </div>
              <div className="text-[0.65rem] tracking-wider font-semibold text-primary -mt-1">
                BE FAST BE PRETTY
              </div>
            </div>
          </a>
          <button
            className="lg:hidden focus:outline-none"
            type="button"
            aria-label="Toggle navigation"
            onClick={() => {
              const nav = document.getElementById("navbarNav");
              nav.classList.toggle("hidden");
            }}
          >
            <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div id="navbarNav" className="hidden lg:flex lg:items-center lg:gap-2">
            <ul className="flex flex-col lg:flex-row items-center gap-2">
              <li>
                <a className="relative px-4 py-2 font-semibold text-[#4a3f35] hover:text-primary transition-colors" href="/home">
                  Home
                </a>
              </li>
              <li>
                <a className="relative px-4 py-2 font-semibold text-[#4a3f35] hover:text-primary transition-colors" href="/mua_reservation">
                  MUA Reservation
                </a>
              </li>
              <li>
                <a className="relative px-4 py-2 font-semibold text-primary" href="/mua_schedule">
                  MUA Schedule
                </a>
              </li>
              <li>
                <a className="relative px-4 py-2 font-semibold text-[#4a3f35] hover:text-primary transition-colors" href="/about_us">
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="/login"
                  className="ml-0 lg:ml-3 bg-primary text-white rounded-full px-6 py-2 font-semibold shadow hover:bg-primary-dark transition"
                >
                  Login
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Content */}
      <section className="container mx-auto mt-32 mb-8 px-3">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8 sm:p-12">
          <h2 className="font-playfair font-semibold text-2xl sm:text-3xl text-[#4a3f35] text-center mb-8">
            Service &amp; Booking List
          </h2>

          <div className="overflow-auto">
            <table className="min-w-full border-separate border-spacing-0">
              <thead>
                <tr className="bg-[#e9d6d9] text-[#5b3d45] font-poppins">
                  <th className="py-4 px-4 font-semibold text-base text-left">MUA Name</th>
                  <th className="py-4 px-4 font-semibold text-base text-left">Expertise</th>
                  <th className="py-4 px-4 font-semibold text-base text-left">Booking Date</th>
                  <th className="py-4 px-4 font-semibold text-base text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.map((item, idx) => {
                  // Format date
                  const date = new Date(item.booking_date);
                  const formattedDate = date.toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  });
                  return (
                    <tr className="transition duration-200 hover:bg-[#f5f0f3] hover:shadow" key={idx}>
                      <td className="py-4 px-4 align-middle">{item.mua_name}</td>
                      <td className="py-4 px-4 align-middle">
                        {item.expertise.map((e, i) => (
                          <span
                            key={i}
                            className="inline-block bg-primary text-white px-3 py-1 rounded-xl text-xs font-medium mr-2 mb-1"
                          >
                            {e}
                          </span>
                        ))}
                      </td>
                      <td className="py-4 px-4 align-middle">{formattedDate}</td>
                      <td className="py-4 px-4 align-middle">
                        <span
                          className={
                            "status inline-block px-4 py-1 rounded-full font-medium text-xs " +
                            (STATUS_COLORS[item.status] || "bg-gray-100 text-gray-800")
                          }
                        >
                          {item.status.replace(/-/g, " ").toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Custom Styles for Tailwind (add in globals.css or tailwind.config.js) */}
      <style jsx global>{`
        :root {
          --primary: #b79ea6;
          --primary-dark: #8a6d75;
        }
        .bg-primary { background-color: var(--primary); }
        .bg-primary-dark { background-color: var(--primary-dark); }
        .text-primary { color: var(--primary); }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .font-poppins { font-family: 'Poppins', sans-serif; }
      `}</style>
    </div>
  );
}